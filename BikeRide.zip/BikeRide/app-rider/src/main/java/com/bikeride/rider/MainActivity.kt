package com.bikeride.rider

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RiderApp() }
    }
}

@Composable
fun RiderApp() {
    var signedIn by remember { mutableStateOf(Firebase.auth.currentUser != null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = RouteBlue)) {
        Surface(Modifier.fillMaxSize()) {
            if (signedIn) {
                RideScreen(onSignOut = { Firebase.auth.signOut(); signedIn = false })
            } else {
                AuthScreen("BikeRide") { signedIn = true }
            }
        }
    }
}
