package com.bikeride.rider

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bikeride.shared.Fare
import com.bikeride.shared.GeoPt
import com.bikeride.shared.RideStatus
import com.bikeride.shared.modeLabel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState

private fun locationGranted(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

@Composable
fun RideScreen(
    onSignOut: () -> Unit,
    vm: RideViewModel = viewModel(key = Firebase.auth.currentUser?.uid)
) {
    val ctx = LocalContext.current
    var hasPerm by remember { mutableStateOf(locationGranted(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPerm = locationGranted(ctx)
    }

    LaunchedEffect(Unit) {
        vm.resumeActive()
        if (!hasPerm) {
            permLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }
    LaunchedEffect(hasPerm) {
        if (hasPerm) currentLocation(ctx)?.let { vm.setMyLoc(it) }
    }

    val camera = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(-6.2, 106.816), 12f)
    }
    val hasLoc = vm.myLoc != null
    LaunchedEffect(hasLoc) {
        vm.myLoc?.let { camera.animate(CameraUpdateFactory.newLatLngZoom(it.toLatLng(), 15f)) }
    }

    val ride = vm.ride
    val pickup: GeoPt? = ride?.pickupPoint() ?: vm.myLoc
    val dest: GeoPt? = ride?.destPoint() ?: vm.dest
    val driverLat = ride?.driverLat
    val driverLng = ride?.driverLng

    Box(Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = camera,
            properties = MapProperties(isMyLocationEnabled = hasPerm),
            uiSettings = MapUiSettings(zoomControlsEnabled = false),
            onMapClick = { vm.pickDest(GeoPt(it.latitude, it.longitude)) }
        ) {
            pickup?.let {
                Marker(state = rememberMarkerState(key = "p${it.lat},${it.lng}", position = it.toLatLng()), title = "Jemput")
            }
            dest?.let {
                Marker(state = rememberMarkerState(key = "d${it.lat},${it.lng}", position = it.toLatLng()), title = "Tujuan")
            }
            if (driverLat != null && driverLng != null) {
                Marker(
                    state = rememberMarkerState(key = "v$driverLat,$driverLng", position = LatLng(driverLat, driverLng)),
                    title = "Pengemudi"
                )
            }
            vm.route?.let { r ->
                Polyline(points = r.points.map { it.toLatLng() }, color = RouteBlue, width = 16f)
            }
        }

        Card(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (ride == null) {
                    val rt = vm.route
                    when {
                        vm.dest == null -> Text("Ketuk peta untuk memilih tujuan")
                        vm.busy -> Text("Mencari rute…")
                        rt != null -> {
                            Text("${"%.1f".format(rt.distanceMeters / 1000.0)} km · ${rt.durationSeconds / 60} menit")
                            Text(Fare.rupiah(Fare.estimate(rt.distanceMeters)), style = MaterialTheme.typography.titleLarge)
                            if (rt.mode != "bicycling") {
                                Text(
                                    "Rute sepeda belum tersedia di daerahmu, memakai rute ${modeLabel(rt.mode)}.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Button(onClick = { vm.request() }, modifier = Modifier.fillMaxWidth()) { Text("Pesan BikeRide") }
                            Text("Bayar tunai", style = MaterialTheme.typography.bodySmall)
                        }
                        else -> Text(vm.error ?: "Rute tidak ditemukan")
                    }
                    if (vm.dest != null) TextButton(onClick = { vm.clearDest() }) { Text("Hapus tujuan") }
                } else {
                    when (ride.rideStatus()) {
                        RideStatus.REQUESTED -> {
                            Text("Mencari pengemudi…")
                            OutlinedButton(onClick = { vm.cancel() }) { Text("Batalkan") }
                        }
                        RideStatus.ACCEPTED -> {
                            Text("Pengemudi menuju lokasimu")
                            OutlinedButton(onClick = { vm.cancel() }) { Text("Batalkan") }
                        }
                        RideStatus.STARTED -> Text("Dalam perjalanan")
                        RideStatus.COMPLETED -> {
                            Text("Perjalanan selesai", style = MaterialTheme.typography.titleMedium)
                            Text("${Fare.rupiah(ride.fare)} (bayar tunai)")
                            Button(onClick = { vm.closeRide() }) { Text("Tutup") }
                        }
                        RideStatus.CANCELLED -> {
                            Text("Pesanan dibatalkan")
                            Button(onClick = { vm.closeRide() }) { Text("Tutup") }
                        }
                    }
                }
                TextButton(onClick = onSignOut) { Text("Keluar") }
            }
        }
    }
}
