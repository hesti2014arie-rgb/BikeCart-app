package com.bikeride.rider

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bikeride.shared.Fare
import com.bikeride.shared.GeoPt
import com.bikeride.shared.Paths
import com.bikeride.shared.Ride
import com.bikeride.shared.RideStatus
import com.bikeride.shared.RouteResult
import com.bikeride.shared.Routing
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.launch

class RideViewModel(app: Application) : AndroidViewModel(app) {
    private val db = Firebase.firestore
    private val key = BuildConfig.MAPS_API_KEY
    private var listener: ListenerRegistration? = null

    var myLoc by mutableStateOf<GeoPt?>(null)
        private set
    var dest by mutableStateOf<GeoPt?>(null)
        private set
    var route by mutableStateOf<RouteResult?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var ride by mutableStateOf<Ride?>(null)
        private set
    var busy by mutableStateOf(false)
        private set

    fun setMyLoc(p: GeoPt) {
        myLoc = p
        if (dest != null && route == null && ride == null) computeRoute()
    }

    fun pickDest(p: GeoPt) {
        if (ride != null) return
        dest = p
        route = null
        computeRoute()
    }

    fun clearDest() {
        if (ride != null) return
        dest = null
        route = null
        error = null
    }

    private fun computeRoute() {
        val a = myLoc ?: return
        val b = dest ?: return
        viewModelScope.launch {
            busy = true
            error = null
            Routing.route(a, b, key)
                .onSuccess { route = it }
                .onFailure { route = null; error = it.message }
            busy = false
        }
    }

    fun request() {
        val a = myLoc ?: return
        val b = dest ?: return
        val r = route ?: return
        val user = Firebase.auth.currentUser ?: return
        val ref = db.collection(Paths.RIDES).document()
        val data = hashMapOf<String, Any?>(
            "riderId" to user.uid,
            "riderName" to (user.displayName ?: "Penumpang"),
            "pickupLat" to a.lat, "pickupLng" to a.lng,
            "destLat" to b.lat, "destLng" to b.lng,
            "distanceMeters" to r.distanceMeters,
            "durationSeconds" to r.durationSeconds,
            "fare" to Fare.estimate(r.distanceMeters),
            "status" to RideStatus.REQUESTED.name,
            "driverId" to null, "driverLat" to null, "driverLng" to null,
            "createdAt" to System.currentTimeMillis()
        )
        ref.set(data)
            .addOnSuccessListener { observe(ref.id) }
            .addOnFailureListener { error = it.message }
    }

    fun resumeActive() {
        val uid = Firebase.auth.currentUser?.uid ?: return
        if (ride != null) return
        db.collection(Paths.RIDES)
            .whereEqualTo("riderId", uid)
            .whereIn("status", listOf("REQUESTED", "ACCEPTED", "STARTED"))
            .limit(1)
            .get()
            .addOnSuccessListener { q -> q.documents.firstOrNull()?.let { observe(it.id) } }
    }

    private fun observe(id: String) {
        listener?.remove()
        listener = db.collection(Paths.RIDES).document(id).addSnapshotListener { snap, _ ->
            val r = snap?.toObject(Ride::class.java)?.also { it.id = snap.id }
            ride = r
            if (r != null && route == null) {
                dest = r.destPoint()
                viewModelScope.launch {
                    Routing.route(r.pickupPoint(), r.destPoint(), key).onSuccess { route = it }
                }
            }
        }
    }

    fun cancel() {
        val r = ride ?: return
        db.collection(Paths.RIDES).document(r.id).update("status", RideStatus.CANCELLED.name)
    }

    fun closeRide() {
        listener?.remove()
        ride = null
        dest = null
        route = null
        error = null
    }

    override fun onCleared() {
        listener?.remove()
    }
}
