package com.bikeride.driver

import android.annotation.SuppressLint
import android.content.Context
import androidx.compose.ui.graphics.Color
import com.bikeride.shared.GeoPt
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.tasks.await

/** Biru jalur rute, mirip Google Maps. */
val RouteBlue = Color(0xFF1A73E8)

fun GeoPt.toLatLng() = LatLng(lat, lng)

@SuppressLint("MissingPermission")
suspend fun currentLocation(ctx: Context): GeoPt? = try {
    val client = LocationServices.getFusedLocationProviderClient(ctx)
    val loc = client.lastLocation.await()
        ?: client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
    loc?.let { GeoPt(it.latitude, it.longitude) }
} catch (e: Exception) {
    null
}
