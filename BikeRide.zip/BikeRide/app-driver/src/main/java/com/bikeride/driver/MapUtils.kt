package com.bikeride.driver

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AColor
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.bikeride.shared.GeoPt
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.tasks.await
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

/** Biru jalur rute, mirip peta populer. */
val RouteBlue = Color(0xFF1A73E8)

data class MapMarker(val point: GeoPt, val title: String, val color: Int)

private fun dot(color: Int, sizePx: Int) = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
    setStroke(5, AColor.WHITE)
    setSize(sizePx, sizePx)
}

/** Peta OpenStreetMap dengan garis rute biru, penanda, dan ketukan peta. */
@Composable
fun OsmMap(
    modifier: Modifier = Modifier,
    focus: GeoPt?,
    myLoc: GeoPt?,
    markers: List<MapMarker>,
    route: List<GeoPt>?,
    onMapClick: ((GeoPt) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val clickCb by rememberUpdatedState(onMapClick)

    val mapView = remember {
        Configuration.getInstance().apply {
            userAgentValue = ctx.packageName
            osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
            osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
        }
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(-6.2, 106.816))
        }
    }

    DisposableEffect(lifecycle, mapView) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        mapView.onResume()
        onDispose {
            lifecycle.removeObserver(obs)
            mapView.onPause()
            mapView.onDetach()
        }
    }

    LaunchedEffect(focus != null) {
        focus?.let {
            mapView.controller.setZoom(16.0)
            mapView.controller.animateTo(GeoPoint(it.lat, it.lng))
        }
    }

    AndroidView(
        factory = { mapView },
        modifier = modifier,
        update = { map ->
            val size = (22 * map.context.resources.displayMetrics.density).toInt()
            map.overlays.clear()

            map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    clickCb?.invoke(GeoPt(p.latitude, p.longitude))
                    return clickCb != null
                }

                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))

            if (!route.isNullOrEmpty()) {
                map.overlays.add(Polyline().apply {
                    setPoints(route.map { GeoPoint(it.lat, it.lng) })
                    outlinePaint.color = RouteBlue.toArgb()
                    outlinePaint.strokeWidth = 14f
                    outlinePaint.strokeCap = Paint.Cap.ROUND
                })
            }

            markers.forEach { m ->
                map.overlays.add(Marker(map).apply {
                    position = GeoPoint(m.point.lat, m.point.lng)
                    title = m.title
                    icon = dot(m.color, size)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                })
            }

            myLoc?.let { me ->
                map.overlays.add(Marker(map).apply {
                    position = GeoPoint(me.lat, me.lng)
                    title = "Posisimu"
                    icon = dot(RouteBlue.toArgb(), size)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                })
            }
            map.invalidate()
        }
    )
}

@SuppressLint("MissingPermission")
suspend fun currentLocation(ctx: Context): GeoPt? = try {
    val client = LocationServices.getFusedLocationProviderClient(ctx)
    val loc = client.lastLocation.await()
        ?: client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
    loc?.let { GeoPt(it.latitude, it.longitude) }
} catch (e: Exception) {
    null
}
