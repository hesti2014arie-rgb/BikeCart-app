package com.bikeride.driver

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bikeride.shared.GeoPt
import com.bikeride.shared.Paths
import com.bikeride.shared.Ride
import com.bikeride.shared.RideStatus
import com.bikeride.shared.RouteResult
import com.bikeride.shared.Routing
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar

class DriverViewModel(app: Application) : AndroidViewModel(app) {
    private val db = Firebase.firestore
    private val key = BuildConfig.MAPS_API_KEY
    private val fused = LocationServices.getFusedLocationProviderClient(app)
    private val uid: String? get() = Firebase.auth.currentUser?.uid

    private var reqListener: ListenerRegistration? = null
    private var activeListener: ListenerRegistration? = null
    private var earnListener: ListenerRegistration? = null
    private var routeJob: Job? = null
    private var locating = false

    var online by mutableStateOf(false)
        private set
    var myLoc by mutableStateOf<GeoPt?>(null)
        private set
    var requests by mutableStateOf<List<Ride>>(emptyList())
        private set
    var skipped by mutableStateOf(setOf<String>())
        private set
    var active by mutableStateOf<Ride?>(null)
        private set
    var route by mutableStateOf<RouteResult?>(null)
        private set
    var earnings by mutableLongStateOf(0L)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    init {
        if (uid != null) {
            listenActive()
            listenEarnings()
        }
    }

    /** Pesanan terdekat yang belum dilewati. */
    val nextRequest: Ride?
        get() {
            val list = requests.filter { it.id !in skipped }
            val me = myLoc ?: return list.firstOrNull()
            return list.minByOrNull { dist(me, it.pickupPoint()) }
        }

    fun distanceToPickup(r: Ride): Float? = myLoc?.let { dist(it, r.pickupPoint()) }

    private fun dist(a: GeoPt, b: GeoPt): Float {
        val out = FloatArray(1)
        Location.distanceBetween(a.lat, a.lng, b.lat, b.lng, out)
        return out[0]
    }

    fun setMyLoc(p: GeoPt) { myLoc = p }
    fun clearMessage() { message = null }
    fun skip(id: String) { skipped = skipped + id }

    // ---------- lokasi ----------
    private val callback = object : LocationCallback() {
        override fun onLocationResult(res: LocationResult) {
            val l = res.lastLocation ?: return
            val p = GeoPt(l.latitude, l.longitude)
            myLoc = p
            val id = uid ?: return
            db.collection(Paths.DRIVERS).document(id).set(
                mapOf("online" to online, "lat" to p.lat, "lng" to p.lng, "updatedAt" to System.currentTimeMillis())
            )
            active?.let {
                db.collection(Paths.RIDES).document(it.id)
                    .update(mapOf("driverLat" to p.lat, "driverLng" to p.lng))
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (locating) return
        locating = true
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000)
            .setMinUpdateIntervalMillis(3000)
            .build()
        try {
            fused.requestLocationUpdates(req, callback, Looper.getMainLooper())
        } catch (e: SecurityException) {
            locating = false
            message = "Izin lokasi belum diberikan"
        }
    }

    private fun stopLocation() {
        fused.removeLocationUpdates(callback)
        locating = false
    }

    // ---------- online / offline ----------
    fun setOnline(on: Boolean) {
        online = on
        if (on) {
            startLocation()
            listenRequests()
        } else {
            reqListener?.remove()
            requests = emptyList()
            if (active == null) stopLocation()
            uid?.let { db.collection(Paths.DRIVERS).document(it).set(mapOf("online" to false)) }
        }
    }

    private fun listenRequests() {
        reqListener?.remove()
        reqListener = db.collection(Paths.RIDES)
            .whereEqualTo("status", RideStatus.REQUESTED.name)
            .addSnapshotListener { snap, _ ->
                requests = snap?.documents
                    ?.mapNotNull { d -> d.toObject(Ride::class.java)?.also { it.id = d.id } }
                    ?: emptyList()
            }
    }

    // ---------- pesanan aktif ----------
    private fun listenActive() {
        val id = uid ?: return
        activeListener?.remove()
        activeListener = db.collection(Paths.RIDES)
            .whereEqualTo("driverId", id)
            .whereIn("status", listOf("ACCEPTED", "STARTED"))
            .addSnapshotListener { snap, _ ->
                val r = snap?.documents?.firstOrNull()
                    ?.let { d -> d.toObject(Ride::class.java)?.also { it.id = d.id } }
                val changed = r?.id != active?.id || r?.status != active?.status
                active = r
                if (r != null) startLocation()
                if (changed) startActiveRouting()
            }
    }

    private fun startActiveRouting() {
        routeJob?.cancel()
        if (active == null) {
            route = null
            if (!online) stopLocation()
            return
        }
        routeJob = viewModelScope.launch {
            while (true) {
                val cur = active ?: break
                val from = myLoc
                if (from == null) {
                    delay(2000)
                    continue
                }
                val to = if (cur.rideStatus() == RideStatus.ACCEPTED) cur.pickupPoint() else cur.destPoint()
                Routing.route(from, to, key)
                    .onSuccess { route = it }
                    .onFailure { message = it.message }
                delay(20_000)
            }
        }
    }

    /** Pratinjau rute pesanan baru: jemput menuju tujuan. */
    fun loadPreview(r: Ride?) {
        if (active != null) return
        routeJob?.cancel()
        if (r == null) {
            route = null
            return
        }
        routeJob = viewModelScope.launch {
            Routing.route(r.pickupPoint(), r.destPoint(), key)
                .onSuccess { route = it }
                .onFailure { route = null; message = it.message }
        }
    }

    fun accept(r: Ride) {
        val id = uid ?: return
        val ref = db.collection(Paths.RIDES).document(r.id)
        db.runTransaction { tx ->
            val s = tx.get(ref)
            if (s.getString("status") != RideStatus.REQUESTED.name) {
                throw FirebaseFirestoreException(
                    "Pesanan sudah diambil pengemudi lain",
                    FirebaseFirestoreException.Code.ABORTED
                )
            }
            tx.update(ref, mapOf("status" to RideStatus.ACCEPTED.name, "driverId" to id))
            null
        }.addOnFailureListener { message = it.message }
    }

    fun setStatus(s: RideStatus) {
        val r = active ?: return
        db.collection(Paths.RIDES).document(r.id).update("status", s.name)
            .addOnFailureListener { message = it.message }
    }

    // ---------- pendapatan ----------
    private fun listenEarnings() {
        val id = uid ?: return
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        earnListener = db.collection(Paths.RIDES)
            .whereEqualTo("driverId", id)
            .whereEqualTo("status", RideStatus.COMPLETED.name)
            .addSnapshotListener { snap, _ ->
                earnings = snap?.documents
                    ?.filter { (it.getLong("createdAt") ?: 0L) >= start }
                    ?.sumOf { it.getLong("fare") ?: 0L }
                    ?: 0L
            }
    }

    override fun onCleared() {
        reqListener?.remove()
        activeListener?.remove()
        earnListener?.remove()
        routeJob?.cancel()
        stopLocation()
    }
}
