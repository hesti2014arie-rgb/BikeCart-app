package com.bikeride.driver

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.auth.ktx.userProfileChangeRequest
import com.google.firebase.ktx.Firebase

@Composable
fun AuthScreen(title: String, onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun valid(): Boolean {
        val ok = email.isNotBlank() && pass.length >= 6
        if (!ok) msg = "Isi email dan kata sandi (minimal 6 karakter)"
        return ok
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Nama (untuk daftar)") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text("Email") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pass, onValueChange = { pass = it },
            label = { Text("Kata sandi") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(enabled = !busy, onClick = {
                msg = ""
                if (valid()) {
                    busy = true
                    Firebase.auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                        busy = false
                        if (t.isSuccessful) onDone() else msg = t.exception?.message ?: "Gagal masuk"
                    }
                }
            }) { Text("Masuk") }
            OutlinedButton(enabled = !busy, onClick = {
                msg = ""
                if (valid()) {
                    busy = true
                    Firebase.auth.createUserWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { t ->
                        if (t.isSuccessful) {
                            val u = t.result.user
                            if (u != null && name.isNotBlank()) {
                                u.updateProfile(userProfileChangeRequest { displayName = name.trim() })
                                    .addOnCompleteListener { busy = false; onDone() }
                            } else {
                                busy = false
                                onDone()
                            }
                        } else {
                            busy = false
                            msg = t.exception?.message ?: "Gagal daftar"
                        }
                    }
                }
            }) { Text("Daftar") }
        }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(msg, color = MaterialTheme.colorScheme.error)
        }
    }
}
