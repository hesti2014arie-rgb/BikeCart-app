package com.bikeride.driver

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bikeride.shared.Fare
import com.bikeride.shared.GeoPt
import com.bikeride.shared.Ride
import com.bikeride.shared.RideStatus
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState

private fun locationGranted(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

@Composable
fun DriverScreen(
    onSignOut: () -> Unit,
    vm: DriverViewModel = viewModel(key = Firebase.auth.currentUser?.uid)
) {
    val ctx = LocalContext.current
    var hasPerm by remember { mutableStateOf(locationGranted(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPerm = locationGranted(ctx)
    }
    val askPerm = {
        permLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    }

    LaunchedEffect(Unit) { if (!hasPerm) askPerm() }
    LaunchedEffect(hasPerm) {
        if (hasPerm) currentLocation(ctx)?.let { vm.setMyLoc(it) }
    }

    val camera = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(-6.2, 106.816), 12f)
    }
    val hasLoc = vm.myLoc != null
    LaunchedEffect(hasLoc) {
        vm.myLoc?.let { camera.animate(CameraUpdateFactory.newLatLngZoom(it.toLatLng(), 15f)) }
    }

    val active = vm.active
    val next = if (vm.online) vm.nextRequest else null
    LaunchedEffect(active?.id, next?.id) { if (active == null) vm.loadPreview(next) }

    val shown: Ride? = active ?: next
    val pickup: GeoPt? = shown?.pickupPoint()
    val dest: GeoPt? = shown?.destPoint()

    Box(Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = camera,
            properties = MapProperties(isMyLocationEnabled = hasPerm),
            uiSettings = MapUiSettings(zoomControlsEnabled = false)
        ) {
            pickup?.let {
                Marker(state = rememberMarkerState(key = "p${it.lat},${it.lng}", position = it.toLatLng()), title = "Jemput")
            }
            dest?.let {
                Marker(state = rememberMarkerState(key = "d${it.lat},${it.lng}", position = it.toLatLng()), title = "Tujuan")
            }
            vm.route?.let { r ->
                Polyline(points = r.points.map { it.toLatLng() }, color = RouteBlue, width = 16f)
            }
        }

        // Bar atas: pendapatan + online
        Card(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(12.dp)) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Pendapatan hari ini", style = MaterialTheme.typography.bodySmall)
                    Text(Fare.rupiah(vm.earnings), style = MaterialTheme.typography.titleMedium)
                }
                Text(if (vm.online) "Online" else "Offline")
                Switch(
                    checked = vm.online,
                    onCheckedChange = { on ->
                        if (on && !hasPerm) askPerm() else vm.setOnline(on)
                    },
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }

        // Panel bawah
        Card(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.message?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.clearMessage() }) { Text("Tutup pesan") }
                }
                when {
                    active != null -> {
                        Text(active.riderName.ifEmpty { "Penumpang" }, style = MaterialTheme.typography.titleMedium)
                        Text("${"%.1f".format(active.distanceMeters / 1000.0)} km · ${Fare.rupiah(active.fare)} (tunai)")
                        if (active.rideStatus() == RideStatus.ACCEPTED) {
                            Text("Menuju titik jemput")
                            Button(onClick = { vm.setStatus(RideStatus.STARTED) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Mulai perjalanan")
                            }
                        } else {
                            Text("Menuju tujuan")
                            Button(onClick = { vm.setStatus(RideStatus.COMPLETED) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Selesai, terima ${Fare.rupiah(active.fare)}")
                            }
                        }
                    }
                    next != null -> {
                        Text("Pesanan baru dari ${next.riderName.ifEmpty { "Penumpang" }}", style = MaterialTheme.typography.titleMedium)
                        vm.distanceToPickup(next)?.let { Text("Jarak jemput: ${"%.1f".format(it / 1000.0)} km") }
                        Text("Perjalanan ${"%.1f".format(next.distanceMeters / 1000.0)} km · ${Fare.rupiah(next.fare)}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.accept(next) }) { Text("Ambil") }
                            OutlinedButton(onClick = { vm.skip(next.id) }) { Text("Lewati") }
                        }
                    }
                    vm.online -> Text("Online. Menunggu pesanan…")
                    else -> Text("Offline. Geser tombol di atas untuk mulai menerima pesanan.")
                }
                TextButton(onClick = { vm.setOnline(false); onSignOut() }) { Text("Keluar") }
            }
        }
    }
}
