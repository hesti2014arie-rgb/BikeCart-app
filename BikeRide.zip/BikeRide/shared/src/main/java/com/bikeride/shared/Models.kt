package com.bikeride.shared

import java.util.Locale

object Paths {
    const val RIDES = "rides"
    const val DRIVERS = "drivers"
}

enum class RideStatus { REQUESTED, ACCEPTED, STARTED, COMPLETED, CANCELLED }

data class GeoPt(val lat: Double = 0.0, val lng: Double = 0.0)

/** Dokumen pesanan di Firestore (koleksi "rides"). Semua properti var + default agar bisa dibaca Firestore. */
data class Ride(
    var id: String = "",
    var riderId: String = "",
    var riderName: String = "",
    var pickupLat: Double = 0.0,
    var pickupLng: Double = 0.0,
    var destLat: Double = 0.0,
    var destLng: Double = 0.0,
    var distanceMeters: Int = 0,
    var durationSeconds: Int = 0,
    var fare: Long = 0,
    var status: String = RideStatus.REQUESTED.name,
    var driverId: String? = null,
    var driverLat: Double? = null,
    var driverLng: Double? = null,
    var createdAt: Long = 0
) {
    fun pickupPoint() = GeoPt(pickupLat, pickupLng)
    fun destPoint() = GeoPt(destLat, destLng)
    fun rideStatus(): RideStatus =
        runCatching { RideStatus.valueOf(status) }.getOrDefault(RideStatus.REQUESTED)
}

/** Tarif contoh (Rupiah). Ubah angkanya sesuai kebutuhan. */
object Fare {
    private const val BASE = 3000L
    private const val PER_KM = 2500L
    private const val MINIMUM = 5000L

    fun estimate(distanceMeters: Int): Long {
        val raw = BASE + (distanceMeters / 1000.0 * PER_KM).toLong()
        val rounded = ((raw + 250) / 500) * 500
        return maxOf(MINIMUM, rounded)
    }

    fun rupiah(v: Long): String = "Rp " + String.format(Locale.US, "%,d", v).replace(',', '.')
}
