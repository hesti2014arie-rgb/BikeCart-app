package com.bikeride.shared

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class RouteResult(
    val points: List<GeoPt>,
    val distanceMeters: Int,
    val durationSeconds: Int,
    val mode: String
)

fun modeLabel(mode: String) = when (mode) {
    "bicycling" -> "sepeda"
    "driving" -> "jalan raya"
    else -> "jalan kaki"
}

object Routing {
    // Server OSRM komunitas (FOSSGIS). Gratis, tanpa API key, tetapi hanya untuk pemakaian wajar
    // (maks. sekitar 1 permintaan per detik). Untuk produksi, jalankan server sendiri.
    private const val BASE = "https://routing.openstreetmap.de"

    /**
     * Mengambil rute. Profil sepeda dicoba dulu; jika tidak tersedia di daerahmu,
     * turun ke jalan raya lalu jalan kaki.
     */
    suspend fun route(from: GeoPt, to: GeoPt): Result<RouteResult> =
        withContext(Dispatchers.IO) {
            var lastError = "Rute tidak ditemukan"
            val profiles = listOf(
                "bicycling" to "routed-bike",
                "driving" to "routed-car",
                "walking" to "routed-foot"
            )
            for ((mode, server) in profiles) {
                try {
                    val url = URL(
                        "$BASE/$server/route/v1/driving/" +
                            "${from.lng},${from.lat};${to.lng},${to.lat}" +
                            "?overview=full&geometries=polyline"
                    )
                    val conn = url.openConnection() as HttpURLConnection
                    conn.setRequestProperty("User-Agent", "BikeRide/1.0 (Android)")
                    conn.connectTimeout = 10_000
                    conn.readTimeout = 10_000
                    val text = try {
                        conn.inputStream.bufferedReader().use { it.readText() }
                    } finally {
                        conn.disconnect()
                    }
                    val json = JSONObject(text)
                    if (json.optString("code") == "Ok") {
                        val r = json.getJSONArray("routes").getJSONObject(0)
                        return@withContext Result.success(
                            RouteResult(
                                points = decode(r.getString("geometry")),
                                distanceMeters = r.getDouble("distance").toInt(),
                                durationSeconds = r.getDouble("duration").toInt(),
                                mode = mode
                            )
                        )
                    }
                    lastError = json.optString("message").ifEmpty { json.optString("code") }
                } catch (e: Exception) {
                    lastError = e.message ?: lastError
                }
            }
            Result.failure(Exception(lastError))
        }

    /** Decode polyline (precision 5). */
    fun decode(encoded: String): List<GeoPt> {
        val out = ArrayList<GeoPt>()
        var index = 0
        var lat = 0
        var lng = 0
        while (index < encoded.length) {
            var result = 0
            var shift = 0
            var b: Int
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1f) shl shift)
                shift += 5
            } while (b >= 0x20)
            lat += if ((result and 1) != 0) (result shr 1).inv() else (result shr 1)

            result = 0
            shift = 0
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1f) shl shift)
                shift += 5
            } while (b >= 0x20)
            lng += if ((result and 1) != 0) (result shr 1).inv() else (result shr 1)

            out.add(GeoPt(lat / 1e5, lng / 1e5))
        }
        return out
    }
}
