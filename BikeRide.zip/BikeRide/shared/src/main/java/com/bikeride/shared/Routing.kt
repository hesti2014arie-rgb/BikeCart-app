package com.bikeride.shared

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class RouteResult(
    val points: List<GeoPt>,
    val distanceMeters: Int,
    val durationSeconds: Int,
    val mode: String
)

fun modeLabel(mode: String) = when (mode) {
    "bicycling" -> "sepeda"
    "driving" -> "jalan raya"
    else -> "jalan kaki"
}

object Routing {
    /**
     * Mengambil rute dari Google Directions API.
     * Mode sepeda dicoba dulu. Jika belum tersedia di daerahmu, turun ke jalan raya lalu jalan kaki.
     */
    suspend fun route(from: GeoPt, to: GeoPt, apiKey: String): Result<RouteResult> =
        withContext(Dispatchers.IO) {
            var lastError = "Rute tidak ditemukan"
            for (mode in listOf("bicycling", "driving", "walking")) {
                try {
                    val url = URL(
                        "https://maps.googleapis.com/maps/api/directions/json" +
                            "?origin=${from.lat},${from.lng}" +
                            "&destination=${to.lat},${to.lng}" +
                            "&mode=$mode&key=$apiKey"
                    )
                    val conn = url.openConnection() as HttpURLConnection
                    conn.connectTimeout = 10_000
                    conn.readTimeout = 10_000
                    val text = try {
                        conn.inputStream.bufferedReader().use { it.readText() }
                    } finally {
                        conn.disconnect()
                    }
                    val json = JSONObject(text)
                    val status = json.optString("status")
                    if (status == "OK") {
                        val route = json.getJSONArray("routes").getJSONObject(0)
                        val leg = route.getJSONArray("legs").getJSONObject(0)
                        return@withContext Result.success(
                            RouteResult(
                                points = decode(route.getJSONObject("overview_polyline").getString("points")),
                                distanceMeters = leg.getJSONObject("distance").getInt("value"),
                                durationSeconds = leg.getJSONObject("duration").getInt("value"),
                                mode = mode
                            )
                        )
                    }
                    lastError = json.optString("error_message").ifEmpty { status }
                    if (status == "REQUEST_DENIED" || status == "OVER_QUERY_LIMIT") break
                } catch (e: Exception) {
                    lastError = e.message ?: lastError
                }
            }
            Result.failure(Exception(lastError))
        }

    /** Decode polyline Google (encoded polyline algorithm). */
    fun decode(encoded: String): List<GeoPt> {
        val out = ArrayList<GeoPt>()
        var index = 0
        var lat = 0
        var lng = 0
        while (index < encoded.length) {
            var result = 0
            var shift = 0
            var b: Int
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1f) shl shift)
                shift += 5
            } while (b >= 0x20)
            lat += if ((result and 1) != 0) (result shr 1).inv() else (result shr 1)

            result = 0
            shift = 0
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1f) shl shift)
                shift += 5
            } while (b >= 0x20)
            lng += if ((result and 1) != 0) (result shr 1).inv() else (result shr 1)

            out.add(GeoPt(lat / 1e5, lng / 1e5))
        }
        return out
    }
}
