# BikeRide dan BikeDriver

Dua aplikasi Android (Kotlin + Jetpack Compose) seperti ojek online, tetapi memakai sepeda.

- **BikeRide**: aplikasi penumpang (pilih tujuan, lihat rute biru dan tarif, pesan, pantau pengemudi)
- **BikeDriver**: aplikasi pengemudi (online/offline, terima pesanan, rute biru, mulai/selesai, pendapatan)
- **shared**: model data, tarif, dan pengambil rute (dipakai kedua aplikasi)

Backend: **Firebase** (Auth email/kata sandi + Firestore).
Peta: **OpenStreetMap** (osmdroid). Rute: **OSRM FOSSGIS** (profil sepeda). Tanpa API key dan tanpa penagihan.

## Yang harus disiapkan: Firebase
1. Buat proyek di console.firebase.google.com
2. Tambahkan **dua** aplikasi Android: `com.bikeride.rider` dan `com.bikeride.driver`
3. Unduh `google-services.json` masing-masing, lalu **ganti** file placeholder di
   `app-rider/google-services.json` dan `app-driver/google-services.json`
4. Authentication, Sign-in method: aktifkan **Email/Password**
5. Firestore Database: buat database, lalu tempel isi `firestore.rules` di tab Rules

## Build lewat GitHub
Upload isi folder ini (atau zip-nya). Workflow `.github/workflows/main.yml` menghasilkan
`BikeRide-V1.apk` dan `BikeDriver-V1.apk` di tab Actions, bagian Artifacts.

## Catatan
- Server rute dan peta gratis hanya untuk pemakaian wajar (maks. sekitar 1 permintaan rute per detik,
  tile OSM tidak untuk lalu lintas besar). Untuk produksi, pakai server rute sendiri (OSRM/GraphHopper)
  dan penyedia tile berlangganan.
- Jika profil sepeda tidak tersedia di daerahmu, aplikasi memakai rute jalan raya lalu jalan kaki.
- Pembayaran V1 hanya tunai. Tarif diatur di `shared/.../Models.kt` (objek `Fare`).
- Pengemudi harus membuka aplikasi (tidak berjalan di latar belakang) agar lokasi terkirim.
- Belum ada pemisahan peran: akun yang sama bisa masuk di kedua aplikasi.
