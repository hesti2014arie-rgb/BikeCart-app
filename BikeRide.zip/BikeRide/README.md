# BikeRide dan BikeDriver

Dua aplikasi Android (Kotlin + Jetpack Compose) seperti ojek online, tetapi memakai sepeda.

- **BikeRide**: aplikasi penumpang (pilih tujuan, lihat rute biru dan tarif, pesan, pantau pengemudi)
- **BikeDriver**: aplikasi pengemudi (online/offline, terima pesanan, rute biru, mulai/selesai, pendapatan)
- **shared**: model data, tarif, dan pengambil rute (dipakai kedua aplikasi)

Backend: **Firebase** (Auth email/kata sandi + Firestore). Peta: **Google Maps** dengan garis rute biru.

## Yang harus disiapkan sebelum jalan

### 1. Firebase
1. Buat proyek di console.firebase.google.com
2. Tambahkan **dua** aplikasi Android: `com.bikeride.rider` dan `com.bikeride.driver`
3. Unduh `google-services.json` masing-masing, lalu **ganti** file placeholder di
   `app-rider/google-services.json` dan `app-driver/google-services.json`
4. Authentication, Sign-in method: aktifkan **Email/Password**
5. Firestore Database: buat database, lalu tempel isi `firestore.rules` di tab Rules

### 2. Google Maps
1. Di Google Cloud Console (proyek yang sama), aktifkan **Maps SDK for Android** dan **Directions API**
2. Buat API key, lalu **batasi** ke nama paket + SHA-1 aplikasi
3. Di GitHub: Settings, Secrets and variables, Actions, buat secret **`MAPS_API_KEY`**
   (build lokal: isi `MAPS_API_KEY=...` di `~/.gradle/gradle.properties`)

## Build lewat GitHub
Upload isi folder ini (atau zip-nya). Workflow `.github/workflows/main.yml` menghasilkan
`BikeRide-V1.apk` dan `BikeDriver-V1.apk` di tab Actions, bagian Artifacts.

## Catatan
- Rute sepeda dari Google belum tersedia di semua negara. Jika tidak ada, aplikasi memakai rute jalan raya lalu jalan kaki.
- Pembayaran V1 hanya tunai. Tarif diatur di `shared/.../Models.kt` (objek `Fare`).
- Pengemudi harus membuka aplikasi (tidak berjalan di latar belakang) agar lokasi terkirim.
- Belum ada pemisahan peran: akun yang sama bisa masuk di kedua aplikasi.
- Directions API memakai kuota berbayar Google. Pantau penggunaannya.
